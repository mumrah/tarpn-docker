This is NOT used for the Linux version.
These are part of the standard C library for Linux and Cygwin.
For the Windows version we need to include our own copy.

They were copied from Cygwin source:

	/usr/src/cygwin-1.7.10-1/newlib/libc/string/strsep.c
	/usr/src/cygwin-1.7.10-1/newlib/libc/string/strtok_r.c

