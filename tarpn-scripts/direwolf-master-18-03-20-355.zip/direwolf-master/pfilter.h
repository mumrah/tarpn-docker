
/* pfilter.h */

int pfilter (int from_chan, int to_chan, char *filter, packet_t pp);