

void dedupe_init (int ttl);

void dedupe_remember (packet_t pp, int chan);

int dedupe_check (packet_t pp, int chan);


/* end dedupe.h */
