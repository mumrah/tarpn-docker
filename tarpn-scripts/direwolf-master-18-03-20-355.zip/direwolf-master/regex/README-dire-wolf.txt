This is NOT used for the Linux version.
For Linux and Cygwin, we use the built-in regular expression library.
For the Windows version, we need to include our own version.

The source was obtained from:

	http://gnuwin32.sourceforge.net/packages/regex.htm