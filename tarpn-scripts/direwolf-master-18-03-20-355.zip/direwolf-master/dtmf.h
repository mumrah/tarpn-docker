/* dtmf.h */


#include "audio.h"

void dtmf_init (struct audio_s *p_audio_config);

char dtmf_sample (int c, float input);


/* end dtmf.h */

