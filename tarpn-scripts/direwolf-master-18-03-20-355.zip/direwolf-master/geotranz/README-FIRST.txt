
This directory contains a subset of geotrans 2.4.2 from

https://github.com/smanders/geotranz

