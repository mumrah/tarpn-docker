
/* Dire Wolf version 1.2 */

#define APP_TOCALL "APDW"

#define MAJOR_VERSION 1
#define MINOR_VERSION 2
#define EXTRA_VERSION "Beta Test"
